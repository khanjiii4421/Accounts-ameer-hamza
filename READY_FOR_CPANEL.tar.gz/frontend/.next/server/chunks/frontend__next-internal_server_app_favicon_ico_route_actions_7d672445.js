module.exports=[22804,(e,o,d)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_favicon_ico_route_actions_7d672445.js.map