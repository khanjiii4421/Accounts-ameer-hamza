module.exports=[55292,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_office-expenses_page_actions_1bf7fb3b.js.map