module.exports=[62191,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_projects_%5Bid%5D_page_actions_73b4645a.js.map