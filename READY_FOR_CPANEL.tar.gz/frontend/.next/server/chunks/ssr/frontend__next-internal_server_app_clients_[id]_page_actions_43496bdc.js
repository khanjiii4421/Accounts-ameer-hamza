module.exports=[59901,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_clients_%5Bid%5D_page_actions_43496bdc.js.map