module.exports=[14944,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_vendors_page_actions_b00c9d61.js.map