module.exports=[66724,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},8592,a=>{"use strict";let b={src:a.i(66724).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=frontend_src_app_b2335e1a._.js.map