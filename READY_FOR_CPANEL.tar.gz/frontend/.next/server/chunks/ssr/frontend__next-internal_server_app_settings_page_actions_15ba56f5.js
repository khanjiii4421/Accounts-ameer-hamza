module.exports=[95070,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_settings_page_actions_15ba56f5.js.map