module.exports=[52497,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_notifications_page_actions_f83b98d9.js.map