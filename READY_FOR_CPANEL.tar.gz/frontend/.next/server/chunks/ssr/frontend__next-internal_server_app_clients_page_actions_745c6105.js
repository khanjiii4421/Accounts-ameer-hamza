module.exports=[18576,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_clients_page_actions_745c6105.js.map