module.exports=[19006,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_login_page_actions_a200ed51.js.map