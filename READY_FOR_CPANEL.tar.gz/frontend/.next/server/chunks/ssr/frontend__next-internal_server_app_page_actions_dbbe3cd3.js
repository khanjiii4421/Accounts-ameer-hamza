module.exports=[98057,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_page_actions_dbbe3cd3.js.map