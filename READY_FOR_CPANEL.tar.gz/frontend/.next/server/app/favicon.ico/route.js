var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__ea812f33._.js")
R.c("server/chunks/frontend__next-internal_server_app_favicon_ico_route_actions_7d672445.js")
R.m(49089)
module.exports=R.m(49089).exports
